Aspect term extraction.
