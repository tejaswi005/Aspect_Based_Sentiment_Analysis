Aspect term extraction using POS tags.
