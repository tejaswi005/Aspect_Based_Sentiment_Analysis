Aspect term extraction using DEP and POS tags.
